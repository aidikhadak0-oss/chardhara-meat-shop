Chardhara Meat Shop - Flutter project patch
===========================================
This archive provides ready-to-use Flutter source files and instructions to build an Android APK locally.
I cannot run `flutter build` in this environment, so I prepared the files and an exact step-by-step guide you can run on your machine.

Steps to produce APK (on your computer)
---------------------------------------
1) Install Flutter SDK and Android SDK & tools if not already:
   https://flutter.dev/docs/get-started/install

2) Create a new Flutter project:
   flutter create chardhara_meat_shop
   cd chardhara_meat_shop

3) Replace files with the ones from this patch:
   - Copy the files from the 'patch' folder into your project's folder.
     If you unzipped this archive into ~/Downloads, for example:
     cp -r ~/Downloads/chardhara_meat_shop_patch/lib/* ./lib/
     cp -r ~/Downloads/chardhara_meat_shop_patch/l10n/* ./l10n/
     cp ~/Downloads/chardhara_meat_shop_patch/pubspec_overrides.yaml ./pubspec_overrides.yaml
     cp ~/Downloads/chardhara_meat_shop_patch/README_build_steps.txt ./

4) Merge pubspec changes:
   Open pubspec.yaml and add the dependencies listed in pubspec_overrides.yaml under 'dependencies' and 'flutter'->'assets' if any.
   Or run:
   flutter pub add intl

5) (Optional but recommended) Replace app launcher icon and app name if desired.

6) Create a release keystore (one-time):
   keytool -genkey -v -keystore ~/chardhara_keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias chardhara_key
   Remember the keystore path, alias, and passwords you set.

7) Configure signing in android/app/build.gradle
   Follow Flutter docs: https://flutter.dev/docs/deployment/android#signing-the-app

   Example (android/key.properties):
     storePassword=<your_store_password>
     keyPassword=<your_key_password>
     keyAlias=chardhara_key
     storeFile=/home/youruser/chardhara_keystore.jks

   And in android/app/build.gradle set signingConfigs to use these properties (see Flutter docs).

8) Build release APK:
   flutter build apk --release

   The generated APK will be in:
   build/app/outputs/flutter-apk/app-release.apk

9) Install on device:
   flutter install
   or transfer the APK to the device and install.

If you prefer an AAB (recommended for Play Store):
   flutter build appbundle --release
   Result: build/app/outputs/bundle/release/app-release.aab

What is included in this patch:
- lib/main.dart : main UI with language toggle and app title "चारधara मासु पसल / Chardhara Meat Shop"
- l10n/intl_en.arb and l10n/intl_ne.arb : sample localization files
- pubspec_overrides.yaml : dependency hints

Need help following these steps? Tell me which step you get stuck on and I will guide you.
