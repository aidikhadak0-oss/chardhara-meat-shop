import 'package:flutter/material.dart';
import 'dart:ui' as ui;

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale _locale = Locale('ne');

  void _toggleLocale() {
    setState(() {
      _locale = _locale.languageCode == 'ne' ? Locale('en') : Locale('ne');
    });
  }

  @override
  Widget build(BuildContext context) {
    final strings = _locale.languageCode == 'ne' ? _localizedNe : _localizedEn;
    return MaterialApp(
      title: strings['appTitle']!,
      debugShowCheckedModeBanner: false,
      home: HomePage(strings: strings, onToggleLocale: _toggleLocale),
    );
  }
}

class HomePage extends StatelessWidget {
  final Map<String, String> strings;
  final VoidCallback onToggleLocale;
  HomePage({required this.strings, required this.onToggleLocale});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(strings['appTitle']!),
        actions: [
          IconButton(
            icon: Icon(Icons.language),
            onPressed: onToggleLocale,
            tooltip: 'Change language',
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _InfoCard(title: strings['todaySales']!, value: 'Rs 0'),
                _InfoCard(title: strings['stockIn']!, value: '0 kg'),
                _InfoCard(title: strings['lowStock']!, value: '0'),
                _InfoCard(title: strings['credit']!, value: 'Rs 0'),
              ],
            ),
            SizedBox(height: 20),
            Text(strings['products']!, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Expanded(
              child: Center(child: Text('Product list will appear here')),
            )
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  _InfoCard({required this.title, required this.value});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
        width: 160,
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(fontSize: 14, color: Colors.grey[700])),
            SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

final Map<String, String> _localizedEn = {
  "appTitle": "Chardhara Meat Shop",
  "dashboard": "Dashboard",
  "todaySales": "Today's Sales",
  "newSale": "New Sale",
  "stockIn": "Stock In",
  "products": "Products",
  "lowStock": "Low Stock",
  "credit": "Credit",
  "reports": "Reports"
};

final Map<String, String> _localizedNe = {
  "appTitle": "चारधारा मासु पसल",
  "dashboard": "ड्यासबोर्ड",
  "todaySales": "आजको बिक्री",
  "newSale": "नयाँ बिक्री",
  "stockIn": "आएको सामान",
  "products": "सामान सूची",
  "lowStock": "कम स्टक",
  "credit": "उधारो",
  "reports": "रिपोर्ट"
};
